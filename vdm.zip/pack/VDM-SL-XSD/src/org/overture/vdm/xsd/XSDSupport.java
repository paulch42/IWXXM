package org.overture.vdm.xsd;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class XSDSupport {

    private static JAXBContext vdmContext;
    public static org.overture.vdm.xsd.ObjectFactory VDM_SCHEMA = null;

    static {
        try {
            vdmContext = JAXBContext.newInstance(org.overture.vdm.xsd.ObjectFactory.class);
            VDM_SCHEMA = new org.overture.vdm.xsd.ObjectFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void marshal(SpecificationSet spec, String file) throws Exception {
        marshal(spec, new FileWriter(file));
    }

    public static void marshal(SpecificationSet spec, Writer w) throws Exception {
        JAXBElement<SpecificationSet> je = VDM_SCHEMA.createSpecificationSet(spec);
        Marshaller m = vdmContext.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        m.marshal(je, w);
    }

    public static SpecificationSet unmarshal(String file) throws Exception {
        return unmarshal(new FileReader(file));
    }

    public static SpecificationSet unmarshal(Reader r) throws Exception {
        Unmarshaller um = vdmContext.createUnmarshaller();
        return ((JAXBElement<SpecificationSet>) um.unmarshal(r)).getValue();
    }

    public static Set<String> freeVars(Bind b) {
        return freeVars(b.getPattern());
    }

    public static Set<String> freeVars(Pattern p) {
        Set<String> s = new TreeSet();
        if (p instanceof IdentifierPattern) {
            s.add(((IdentifierPattern) p).getName());
        }
        List<Pattern> lp = new ArrayList();
        if (p instanceof BinaryPattern) {
            lp.add(((BinaryPattern) p).getOp1());
            lp.add(((BinaryPattern) p).getOp2());
        }
        if (p instanceof SetEnumerationPattern) {
            lp.addAll(((SetEnumerationPattern) p).getItem());
        }
        if (p instanceof SeqEnumerationPattern) {
            lp.addAll(((SeqEnumerationPattern) p).getItem());
        }
        if (p instanceof MapEnumerationPattern) {
            lp.addAll(((MapEnumerationPattern) p).getItem());
        }
        if (p instanceof MapletPattern) {
            lp.add(((MapletPattern) p).getDomain());
            lp.add(((MapletPattern) p).getRange());
        }
        if (p instanceof TuplePattern) {
            lp.addAll(((TuplePattern) p).getItem());
        }
        if (p instanceof RecordPattern) {
            lp.addAll(((RecordPattern) p).getItem());
        }
        for (Pattern pat : lp) {
            s.addAll(freeVars(pat));
        }
        return s;
    }

    public static ExportSet exports(Specification spec) {
        ExportSet es = new ExportSet();
        if (spec instanceof Module) {
            for (ExportDeclaration ed : ((Module) spec).getExport()) {
                addExport(ed, es);
            }
        }
        return es;
    }

    private static void addExport(ExportDeclaration ed, ExportSet es) {
        if (ed instanceof TypeExport) {
            TypeExport te = (TypeExport) ed;
            es.types.add(te.getName());
            if (te.isExposed()) {
                es.exposedTypes.add(te.getName());
            }
        }
        if (ed instanceof ValueExport) {
            es.values.add(((ValueExport) ed).getName());
        }
        if (ed instanceof FunctionExport) {
            es.functions.add(((FunctionExport) ed).getName());
        }
        if (ed instanceof OperationExport) {
            es.operations.add(((OperationExport) ed).getName());
        }
    }

    public static class ExportSet {

        public Set<String> types = new TreeSet();
        public Set<String> exposedTypes = new TreeSet();
        public Set<String> values = new TreeSet();
        public Set<String> functions = new TreeSet();
        public Set<String> operations = new TreeSet();
    }
    
    public static boolean isAtomic(Type t) {
        return t instanceof BasicType || t instanceof QuoteType || t instanceof NamedType || t instanceof VariableType || t instanceof VoidType;
    }

    public static boolean isAtomic(Expression e) {
        return e instanceof NameExpression || e instanceof LiteralExpression || e instanceof UndefinedExpression || e instanceof ResultExpression;
    }
}
