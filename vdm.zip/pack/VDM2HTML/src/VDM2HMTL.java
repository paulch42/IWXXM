
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.overture.vdm.xsd.AnonymousPattern;
import org.overture.vdm.xsd.ApplyExpression;
import org.overture.vdm.xsd.BasicType;
import org.overture.vdm.xsd.BinaryExpression;
import org.overture.vdm.xsd.BinaryOperator;
import org.overture.vdm.xsd.BinaryPattern;
import org.overture.vdm.xsd.Bind;
import org.overture.vdm.xsd.BooleanLiteralExpression;
import org.overture.vdm.xsd.CaseAlternate;
import org.overture.vdm.xsd.CasesExpression;
import org.overture.vdm.xsd.CharacterLiteralExpression;
import org.overture.vdm.xsd.CompositeType;
import org.overture.vdm.xsd.DecimalLiteralExpression;
import org.overture.vdm.xsd.DefExpression;
import org.overture.vdm.xsd.Definition;
import org.overture.vdm.xsd.Expression;
import org.overture.vdm.xsd.ExpressionPattern;
import org.overture.vdm.xsd.FunctionDefinition;
import org.overture.vdm.xsd.FunctionIdentifier;
import org.overture.vdm.xsd.FunctionType;
import org.overture.vdm.xsd.IdentifierPattern;
import org.overture.vdm.xsd.IfExpression;
import org.overture.vdm.xsd.IfThen;
import org.overture.vdm.xsd.IntegralLiteralExpression;
import org.overture.vdm.xsd.Invariant;
import org.overture.vdm.xsd.IsExpression;
import org.overture.vdm.xsd.LabelledField;
import org.overture.vdm.xsd.LambdaExpression;
import org.overture.vdm.xsd.LetBeExpression;
import org.overture.vdm.xsd.LetExpression;
import org.overture.vdm.xsd.MapComprehension;
import org.overture.vdm.xsd.MapEnumeration;
import org.overture.vdm.xsd.MapEnumerationPattern;
import org.overture.vdm.xsd.MapType;
import org.overture.vdm.xsd.Maplet;
import org.overture.vdm.xsd.MapletPattern;
import org.overture.vdm.xsd.Module;
import org.overture.vdm.xsd.NameExpression;
import org.overture.vdm.xsd.NamedType;
import org.overture.vdm.xsd.NarrowExpression;
import org.overture.vdm.xsd.NilLiteralExpression;
import org.overture.vdm.xsd.OperationDefinition;
import org.overture.vdm.xsd.OperationIdentifier;
import org.overture.vdm.xsd.OperationType;
import org.overture.vdm.xsd.OptionalType;
import org.overture.vdm.xsd.ParameterGroup;
import org.overture.vdm.xsd.Pattern;
import org.overture.vdm.xsd.PreExpression;
import org.overture.vdm.xsd.ProductType;
import org.overture.vdm.xsd.QuantifiedExpression;
import org.overture.vdm.xsd.QuoteLiteralExpression;
import org.overture.vdm.xsd.QuoteType;
import org.overture.vdm.xsd.Range;
import org.overture.vdm.xsd.RecordExpression;
import org.overture.vdm.xsd.RecordModification;
import org.overture.vdm.xsd.RecordModifier;
import org.overture.vdm.xsd.RecordPattern;
import org.overture.vdm.xsd.RecordSelectExpression;
import org.overture.vdm.xsd.Relation;
import org.overture.vdm.xsd.ResultExpression;
import org.overture.vdm.xsd.SeqBind;
import org.overture.vdm.xsd.SeqComprehension;
import org.overture.vdm.xsd.SeqEnumeration;
import org.overture.vdm.xsd.SeqEnumerationPattern;
import org.overture.vdm.xsd.SeqType;
import org.overture.vdm.xsd.SetBind;
import org.overture.vdm.xsd.SetComprehension;
import org.overture.vdm.xsd.SetEnumeration;
import org.overture.vdm.xsd.SetEnumerationPattern;
import org.overture.vdm.xsd.SetRange;
import org.overture.vdm.xsd.SetType;
import org.overture.vdm.xsd.Specification;
import org.overture.vdm.xsd.SpecificationSet;
import org.overture.vdm.xsd.StateDefinition;
import org.overture.vdm.xsd.Statement;
import org.overture.vdm.xsd.Subsequence;
import org.overture.vdm.xsd.TextLiteralExpression;
import org.overture.vdm.xsd.TraceDefinition;
import org.overture.vdm.xsd.TupleExpression;
import org.overture.vdm.xsd.TuplePattern;
import org.overture.vdm.xsd.TupleSelectExpression;
import org.overture.vdm.xsd.Type;
import org.overture.vdm.xsd.TypeBind;
import org.overture.vdm.xsd.TypeDefinition;
import org.overture.vdm.xsd.UnaryExpression;
import org.overture.vdm.xsd.UnaryOperator;
import org.overture.vdm.xsd.UndefinedExpression;
import org.overture.vdm.xsd.UnionType;
import org.overture.vdm.xsd.ValueDefinition;
import org.overture.vdm.xsd.ValueIdentifier;
import org.overture.vdm.xsd.VariableType;
import org.overture.vdm.xsd.VoidType;
import org.overture.vdm.xsd.XSDSupport;
import org.overture.vdm.xsd.XSDSupport.ExportSet;

public class VDM2HMTL {

    private static Context context;

    private static void initContext() {
        context = new Context();
        context.newLevel(0, 0);
    }

    public static void VDM2HTML(SpecificationSet ss) throws Exception {
        index(new FileWriter(HTML.INDEX_FILE), HTMLParameters.cssFile);
        menu(HTMLParameters.cssFile, ss);
        for (Specification s : ss.getSpecification()) {
            specification(s);
        }
    }

    public static void index(Writer w, String vdmCssFilename) throws Exception {
        w.append(HTML.doctype());
        w.append(HTML.openTag(HTML.HTML_TAG));
        w.append(HTML.head("VDM", vdmCssFilename));
        w.append(HTML.openTag(HTML.BODY_TAG));
        w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_LIST));
        w.append(HTML.element(HTML.IFRAME_TAG, HTML.ATTRIBUTE_SRC, HTML.MENU_FILE));
        w.append(HTML.closeTag(HTML.SPAN_TAG));
        w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_SPEC));
        w.append(HTML.element(HTML.IFRAME_TAG, HTML.ATTRIBUTE_NAME, HTML.SPEC_FRAME));
        w.append(HTML.closeTag(HTML.SPAN_TAG));
        w.append(HTML.closeTag(HTML.BODY_TAG));
        w.append(HTML.closeTag(HTML.HTML_TAG));
        w.close();
    }

    public static void menu(String vdmCssFilename, SpecificationSet ss) throws Exception {
        Writer w = new FileWriter(HTML.MENU_FILE);
        w.append(HTML.doctype());
        w.append(HTML.head("VDM", HTMLParameters.cssFile));
        w.append(HTML.openTag(HTML.BODY_TAG));
        w.append(HTML.element(HTML.H3_TAG, "Specifications"));
        w.append(HTML.closeTag(HTML.BODY_TAG));
        for (Specification s : ss.getSpecification()) {
            ExportSet exports = XSDSupport.exports(s);
            String htmlFile = s.getName() + ".html";
            w.append(HTML.openDetails(false));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MODULE));
            w.append(HTML.a(HTML.CLASS_REFERENCE, htmlFile, HTML.SPEC_FRAME, s.getName()));
            w.append(HTML.closeTag(HTML.SPAN_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.UL_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MENU));
            if (s instanceof Module) {
                menuTypes(w, htmlFile, s.getType(), exports.types, exports.exposedTypes);
                menuState(w, htmlFile, s.getState());
                menuValues(w, htmlFile, s.getValue(), exports.values);
                menuFunctions(w, htmlFile, s.getFunction(), exports.functions);
                menuOperations(w, htmlFile, s.getOperation(), exports.operations);
            } else {
                menuTypes(w, htmlFile, s.getType(), null, null);
                menuState(w, htmlFile, s.getState());
                menuValues(w, htmlFile, s.getValue(), null);
                menuFunctions(w, htmlFile, s.getFunction(), null);
                menuOperations(w, htmlFile, s.getOperation(), null);
            }
            w.append(HTML.closeTag(HTML.UL_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
        }
        w.append(HTML.closeTag(HTML.HTML_TAG));
        w.close();
    }

    static void menuTypes(Writer w, String file, List<TypeDefinition> defs, Set<String> exports, Set<String> exposed) throws Exception {
        if (!defs.isEmpty()) {
            w.append(HTML.openTag(HTML.LI_TAG));
            w.append(HTML.openDetails(false));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TYPE));
            w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + HTML.ID_TYPES, HTML.SPEC_FRAME, "Types"));
            w.append(HTML.closeTag(HTML.SPAN_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.UL_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MENU));
            for (TypeDefinition t : defs) {
                boolean isExported = exports != null && (exports.isEmpty() || exports.contains(t.getName()));
                boolean isExposed = isExported && (exports.isEmpty() || exposed.contains(t.getName()));
                w.append(HTML.openTag(HTML.LI_TAG, HTML.ATTRIBUTE_CLASS, !isExported ? HTML.CLASS_NOEXPORT : isExposed ? HTML.CLASS_EXPOSE : HTML.CLASS_EXPORT));
                w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TYPE));
                w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + t.getName(), HTML.SPEC_FRAME, t.getName()));
                w.append(HTML.closeTag(HTML.SPAN_TAG));
                w.append(HTML.closeTag(HTML.LI_TAG));
            }
            w.append(HTML.closeTag(HTML.UL_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
            w.append(HTML.closeTag(HTML.LI_TAG));
        }
    }

    static void menuState(Writer w, String file, StateDefinition def) throws Exception {
        if (def != null) {
            w.append(HTML.openTag(HTML.LI_TAG));
            w.append(HTML.openDetails(false));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_STATE));
            w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + HTML.ID_STATE, HTML.SPEC_FRAME, "State"));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.UL_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MENU));
            w.append(HTML.openTag(HTML.LI_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_NOEXPORT));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_STATE));
            w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + def.getName(), HTML.SPEC_FRAME, def.getName()));
            w.append(HTML.closeTag(HTML.SPAN_TAG));
            w.append(HTML.closeTag(HTML.LI_TAG));
            w.append(HTML.closeTag(HTML.UL_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
            w.append(HTML.closeTag(HTML.LI_TAG));
        }
    }

    static void menuValues(Writer w, String file, List<ValueDefinition> defs, Set<String> exports) throws Exception {
        if (!defs.isEmpty()) {
            w.append(HTML.openTag(HTML.LI_TAG));
            w.append(HTML.openDetails(false));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_VALUE));
            w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + HTML.ID_VALUES, HTML.SPEC_FRAME, "Values"));
            w.append(HTML.closeTag(HTML.SPAN_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.UL_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MENU));
            for (ValueDefinition t : defs) {
                Set<String> vars = XSDSupport.freeVars(t.getBind());
                for (String s : vars) {
                    w.append(HTML.openTag(HTML.LI_TAG, HTML.ATTRIBUTE_CLASS, exports != null && (exports.isEmpty() || exports.contains(s)) ? HTML.CLASS_EXPORT : HTML.CLASS_NOEXPORT));
                    w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_VALUE));
                    w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + s, HTML.SPEC_FRAME, s));
                    w.append(HTML.closeTag(HTML.SPAN_TAG));
                    w.append(HTML.closeTag(HTML.LI_TAG));
                }
            }
            w.append(HTML.closeTag(HTML.UL_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
            w.append(HTML.closeTag(HTML.LI_TAG));
        }
    }

    static void menuFunctions(Writer w, String file, List<FunctionDefinition> defs, Set<String> exports) throws Exception {
        if (!defs.isEmpty()) {
            w.append(HTML.openTag(HTML.LI_TAG));
            w.append(HTML.openDetails(false));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_FUNCTION));
            w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + HTML.ID_FUNCTIONS, HTML.SPEC_FRAME, "Functions"));
            w.append(HTML.closeTag(HTML.SPAN_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.UL_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MENU));
            for (FunctionDefinition t : defs) {
                w.append(HTML.openTag(HTML.LI_TAG, HTML.ATTRIBUTE_CLASS, exports != null && (exports.isEmpty() || exports.contains(t.getName())) ? HTML.CLASS_EXPORT : HTML.CLASS_NOEXPORT));
                w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_FUNCTION));
                w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + t.getName(), HTML.SPEC_FRAME, t.getName()));
                w.append(HTML.closeTag(HTML.SPAN_TAG));
                w.append(HTML.closeTag(HTML.LI_TAG));
            }
            w.append(HTML.closeTag(HTML.UL_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
            w.append(HTML.closeTag(HTML.LI_TAG));
        }
    }

    static void menuOperations(Writer w, String file, List<OperationDefinition> defs, Set<String> exports) throws Exception {
        if (!defs.isEmpty()) {
            w.append(HTML.openTag(HTML.LI_TAG));
            w.append(HTML.openDetails(false));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_OPERATION));
            w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + HTML.ID_OPERATIONS, HTML.SPEC_FRAME, "Operations"));
            w.append(HTML.closeTag(HTML.SPAN_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.UL_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_MENU));
            for (OperationDefinition t : defs) {
                w.append(HTML.openTag(HTML.LI_TAG, HTML.ATTRIBUTE_CLASS, exports != null && (exports.isEmpty() || exports.contains(t.getName())) ? HTML.CLASS_EXPORT : HTML.CLASS_NOEXPORT));
                w.append(HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_OPERATION));
                w.append(HTML.a(HTML.CLASS_REFERENCE, file + "#" + t.getName(), HTML.SPEC_FRAME, t.getName()));
                w.append(HTML.closeTag(HTML.SPAN_TAG));
                w.append(HTML.closeTag(HTML.LI_TAG));
            }
            w.append(HTML.closeTag(HTML.UL_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
            w.append(HTML.closeTag(HTML.LI_TAG));
        }
    }

    public static void specification(Specification spec) throws Exception {
        Writer w = new FileWriter(spec.getName() + ".html");
        boolean isModule = spec instanceof Module;
        w.append(HTML.doctype());
        w.append(HTML.openTag(HTML.HTML_TAG));
        w.append(HTML.head(spec.getName(), HTMLParameters.cssFile, HTMLParameters.customFile));
        w.append(HTML.openTag(HTML.BODY_TAG));
        w.append(HTML.openTag(HTML.HEADER_TAG));
        w.append(HTML.element(HTML.H1_TAG, (isModule ? "Module: " : "") + spec.getName()));
        w.append(HTML.closeTag(HTML.HEADER_TAG));
        w.append(HTML.element(HTML.HR_TAG));
        if (spec.getComment() != null) {
            w.append(spec.getComment());
        }
        if (!spec.getType().isEmpty()) {
            w.append(HTML.openDetails(true, HTML.ATTRIBUTE_ID, HTML.ID_TYPES));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.H2_TAG));
            w.append(HTML.anchor(HTML.ID_TYPES, "Types"));
            w.append(HTML.closeTag(HTML.H2_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            for (TypeDefinition t : spec.getType()) {
                w.append(HTML.element(HTML.HR_TAG));
                if (t.getComment() != null) {
                    w.append(t.getComment());
                }
                w.append(HTML.openTag(HTML.SECTION_TAG));
                w.append(HTML.openDetails(true));
                w.append(HTML.openTag(HTML.SUMMARY_TAG));
                w.append(HTML.anchor(t.getName(), t.getName()));
                w.append(HTML.closeTag(HTML.SUMMARY_TAG));
                w.append(definition(t));
                w.append(HTML.closeTag(HTML.DETAILS_TAG));
                w.append(HTML.closeTag(HTML.SECTION_TAG));
            }
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
        }
        if (spec.getState() != null) {
            w.append(HTML.openDetails(true, HTML.ATTRIBUTE_ID, HTML.ID_STATE));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.H2_TAG));
            w.append(HTML.anchor(HTML.ID_STATE, "State"));
            w.append(HTML.closeTag(HTML.H2_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(HTML.element(HTML.HR_TAG));
            if (spec.getState().getComment() != null) {
                w.append(spec.getState().getComment());
            }
            w.append(HTML.openTag(HTML.SECTION_TAG));
            w.append(HTML.openDetails(true));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.anchor(spec.getState().getName(), spec.getState().getName()));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            w.append(definition(spec.getState()));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
            w.append(HTML.closeTag(HTML.SECTION_TAG));
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
        }
        if (!spec.getValue().isEmpty()) {
            w.append(HTML.openDetails(true, HTML.ATTRIBUTE_ID, HTML.ID_VALUES));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.H2_TAG));
            w.append(HTML.anchor(HTML.ID_VALUES, "Values"));
            w.append(HTML.closeTag(HTML.H2_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            for (ValueDefinition t : spec.getValue()) {
                w.append(HTML.element(HTML.HR_TAG));
                if (t.getComment() != null) {
                    w.append(t.getComment());
                }
                w.append(HTML.openTag(HTML.SECTION_TAG));
                w.append(HTML.openDetails(true));
                w.append(HTML.openTag(HTML.SUMMARY_TAG));
                initContext();
                pattern(t.getBind().getPattern(), false);
                w.append(context.text());
                w.append(HTML.closeTag(HTML.SUMMARY_TAG));
                w.append(definition(t));
                w.append(HTML.closeTag(HTML.DETAILS_TAG));
                w.append(HTML.closeTag(HTML.SECTION_TAG));
            }
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
        }
        if (!spec.getFunction().isEmpty()) {
            w.append(HTML.openDetails(true, HTML.ATTRIBUTE_ID, HTML.ID_FUNCTIONS));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.H2_TAG));
            w.append(HTML.anchor(HTML.ID_FUNCTIONS, "Functions"));
            w.append(HTML.closeTag(HTML.H2_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            for (FunctionDefinition t : spec.getFunction()) {
                w.append(HTML.element(HTML.HR_TAG));
                if (t.getComment() != null) {
                    w.append(t.getComment());
                }
                w.append(HTML.openTag(HTML.SECTION_TAG));
                w.append(HTML.openDetails(true));
                w.append(HTML.openTag(HTML.SUMMARY_TAG));
                w.append(HTML.anchor(t.getName(), t.getName()));
                w.append(HTML.closeTag(HTML.SUMMARY_TAG));
                w.append(definition(t));
                w.append(HTML.closeTag(HTML.DETAILS_TAG));
                w.append(HTML.closeTag(HTML.SECTION_TAG));
            }
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
        }
        if (!spec.getOperation().isEmpty()) {
            w.append(HTML.openDetails(true, HTML.ATTRIBUTE_ID, HTML.ID_OPERATIONS));
            w.append(HTML.openTag(HTML.SUMMARY_TAG));
            w.append(HTML.openTag(HTML.H2_TAG));
            w.append(HTML.anchor(HTML.ID_OPERATIONS, "Operations"));
            w.append(HTML.closeTag(HTML.H2_TAG));
            w.append(HTML.closeTag(HTML.SUMMARY_TAG));
            for (OperationDefinition t : spec.getOperation()) {
                w.append(HTML.element(HTML.HR_TAG));
                if (t.getComment() != null) {
                    w.append(t.getComment());
                }
                w.append(HTML.openTag(HTML.SECTION_TAG));
                w.append(HTML.openDetails(true));
                w.append(HTML.openTag(HTML.SUMMARY_TAG));
                w.append(HTML.anchor(t.getName(), t.getName()));
                w.append(HTML.closeTag(HTML.SUMMARY_TAG));
                w.append(definition(t));
                w.append(HTML.closeTag(HTML.DETAILS_TAG));
                w.append(HTML.closeTag(HTML.SECTION_TAG));
            }
            w.append(HTML.closeTag(HTML.DETAILS_TAG));
        }
        if (isModule) {
        }
        if (isModule) {
        }
        w.append(HTML.closeTag(HTML.BODY_TAG));
        w.append(HTML.closeTag(HTML.HTML_TAG));
        w.close();
    }

    static String definition(Definition def) {
        String res = HTML.openTag(HTML.CODE_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_DEFINITION);
        if (def instanceof TypeDefinition) {
            res += typeDefinition((TypeDefinition) def);
        }
        if (def instanceof StateDefinition) {
            res += stateDefinition((StateDefinition) def);
        }
        if (def instanceof ValueDefinition) {
            res += valueDefinition((ValueDefinition) def);
        }
        if (def instanceof FunctionDefinition) {
            res += functionDefinition((FunctionDefinition) def);
        }
        if (def instanceof OperationDefinition) {
            res += operationDefinition((OperationDefinition) def);
        }
        if (def instanceof TraceDefinition) {
            res += traceDefinition((TraceDefinition) def);
        }
        res += HTML.closeTag(HTML.CODE_TAG);
        return res;
    }

    static void definitionLocal(Definition def) {
        if (def instanceof TypeDefinition) {
            typeDefinition((TypeDefinition) def);
        }
        if (def instanceof StateDefinition) {
            stateDefinition((StateDefinition) def);
        }
        if (def instanceof ValueDefinition) {
            valueDefinitionLocal((ValueDefinition) def);
        }
        if (def instanceof FunctionDefinition) {
            functionDefinition((FunctionDefinition) def);
        }
        if (def instanceof OperationDefinition) {
            operationDefinition((OperationDefinition) def);
        }
        if (def instanceof TraceDefinition) {
            traceDefinition((TraceDefinition) def);
        }
    }

    static String definitionList(List<Definition> lt) {
        String res = "";
        for (Definition b : lt.subList(1, lt.size())) {
            res += definition(b);
        }
        return res;
    }

    static void definitionListLocal(List<Definition> lt) {
        context.newLevel(context.startRow(), context.endCol());
        definitionLocal(lt.get(0));
        context.merge();
        for (Definition b : lt.subList(1, lt.size())) {
            context.nl();
            context.newLevel(context.startRow(), context.endCol());
            definitionLocal(b);
            context.merge();
        }
    }

    static String typeDefinition(TypeDefinition def, int indent) {
        initContext();
        type(def.getType(), indent, def.getName());
        String res = context.text();
        res += invariant(def.getInv(), "Invariant");
        res += relation(def.getEq(), "Equality");
        res += relation(def.getOrd(), "Order");
        return res;
    }

    static String typeDefinition(TypeDefinition def) {
        return typeDefinition(def, 0);
    }

    static String invariant(Invariant inv, String label) {
        String res = "";
        if (inv != null) {
            res = HTML.openTag(HTML.FIELDSET_TAG);
            res += HTML.element(HTML.LEGEND_TAG, label);
            initContext();
            pattern(inv.getPattern());
            context.add(sp());
            String eq = "==";
            context.add(token(eq), eq.length());
            context.add(sp());
            expression(inv.getExpression());
            res += context.text();
            res += HTML.closeTag(HTML.FIELDSET_TAG);
        }
        return res;
    }

    static String relation(Relation rel, String label) {
        String res = "";
        if (rel != null) {
            res = HTML.openTag(HTML.FIELDSET_TAG);
            res += HTML.element(HTML.LEGEND_TAG, label);
            initContext();
            pattern(rel.getPattern());
            context.add(sp());
            String eq = "==";
            context.add(token(eq), eq.length());
            context.add(sp());
            expression(rel.getExpression());
            res += context.text();
            res += HTML.closeTag(HTML.FIELDSET_TAG);
        }
        return res;
    }

    static String constraint(Expression exp, String label) {
        String res = "";
        if (exp != null) {
            res = HTML.openTag(HTML.FIELDSET_TAG);
            res += HTML.element(HTML.LEGEND_TAG, label);
            initContext();
            expression(exp);
            res += context.text();
            res += HTML.closeTag(HTML.FIELDSET_TAG);
        }
        return res;
    }

    static String stateDefinition(StateDefinition def, int indent) {
        initContext();
        fieldList(def.getField());
        String res = context.text();
        res += invariant(def.getInv(), "Invariant");
        res += invariant(def.getInit(), "Initial State");
        return res;
    }

    static String stateDefinition(StateDefinition def) {
        return stateDefinition(def, 0);
    }

    static String valueDefinition(ValueDefinition def) {
        initContext();
        String res = "";
        if (def.getBind() instanceof TypeBind) {
            // For top-level defintions, present the type but not the pattern (which is presented elsewhere).
            type(((TypeBind) def.getBind()).getType());
            res = context.text();
        }
        res += HTML.element(HTML.HR_TAG);
        initContext();
        expression(def.getValue());
        res += context.text();
        return res;
    }

    static void valueDefinitionLocal(ValueDefinition def) {
        // For local defintions, present the pattern but not the type.
        context.newLevel(context.startRow(), context.endCol());
        pattern(def.getBind().getPattern());
        context.merge();
        context.add(sp());
        String label = "=";
        context.add(token(label), label.length());
        context.add(sp());
        context.newLevel(context.startRow(), context.endCol());
        expression(def.getValue());
        context.merge();
    }

    static String functionDefinition(FunctionDefinition def) {
        initContext();
        typeSignature(def.getParameterGroup(), def.getResult());
        String res = context.text();
        if (def.getBody() != null && !def.getBody().isNil()) {
            res += HTML.element(HTML.HR_TAG);
            initContext();
            expression(def.getBody().getValue());
            res += context.text();
        }
        res += constraint(def.getPre(), "Precondition");
        res += constraint(def.getPost(), "Postcondition");
        if (def.getMeasure() != null && !def.getMeasure().isNil()) {
            res += constraint(def.getMeasure().getValue(), "Measure");
        }
        return res;
    }

    static void typeSignature(List<ParameterGroup> lpg, TypeBind tb) {
        if (lpg == null || lpg.isEmpty()) {
            context.ldelim(true, "(");
            context.rdelim(true, ")");
            context.add(sp());
            String label = "->";
            context.add(token(label), label.length());
            context.add(sp());
        } else {
            for (ParameterGroup pg : lpg) {
                context.ldelim(true, "(");
                parameterGroup(pg);
                context.rdelim(true, ")");
                context.add(sp());
                String label = pg.isPartial() ? "->" : "+>";
                context.add(token(label), label.length());
                context.add(sp());
            }
        }
        context.ldelim(true, "(");
        bind(tb);
        context.rdelim(true, ")");
    }

    static void parameterGroup(ParameterGroup pg) {
        List<Bind> lb = new ArrayList();
        lb.addAll(pg.getParameter());
        bindList(lb, ",");
    }

    static void bindList(List<Bind> lb, String sep) {
        if (!lb.isEmpty()) {
            bind(lb.get(0));
            for (Bind b : lb.subList(1, lb.size())) {
                context.add(sp());
                context.add(token(sep), sep.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                bind(b);
                context.merge();
            }
        }
    }

    // Inline function definition
    static String functionDefinition(FunctionDefinition def, int indent) {
        String res = def.getName();
        for (ParameterGroup pg : def.getParameterGroup()) {
            List<Bind> lb = new ArrayList();
            lb.addAll(pg.getParameter());
            //res += bindList(lb, indent + res.length(), "(", ", ", ")");
            res += sp();
            res += token(pg.isPartial() ? "->" : "+>");
            res += sp();
        }
        //res += delimit(indent + res.length(), "(", def.getResult(), ")");
        res += sp();
        res += token("=");
        res += sp();
        if (def.getBody() != null) {
            if (def.getBody().isNil()) {
                res += token("is not yet specified");
            } else {
                expression(def.getBody().getValue());
            }
        }
        if (def.getPre() != null || def.getPost() != null || def.getMeasure() != null) {
            res += nl(indent);
        }
        if (def.getPre() != null) {
            constraint(def.getPre(), "Precondition");
        }
        if (def.getPost() != null) {
            if (def.getPre() != null) {
                res += nl(indent);
            }
            //res += condition("post", def.getPost(), indent);
        }
        if (def.getMeasure() != null) {
            if (def.getPre() != null || def.getPost() != null) {
                res += nl(indent);
            }
            if (def.getMeasure().isNil()) {
                res += token("in not yet specified");
            } else {
                expression(def.getMeasure().getValue());
            }
        }
        return res;
    }

    static String operationDefinition(OperationDefinition def, int indent) {
        String res = "";
        if (def.isPure()) {
            res += token("pure") + sp();
        }
        List<ParameterGroup> lpg = new ArrayList();
        lpg.add(def.getParameterGroup());
        typeSignature(lpg, def.getResult());
        if (def.getBody() != null && !def.getBody().isNil()) {
            res += statement(def.getBody().getValue());
        }
        // external
        res += constraint(def.getPre(), "Precondition");
        res += constraint(def.getPost(), "Postcondition");
        // handler
        return res;
    }

    static String operationDefinition(OperationDefinition def) {
        return operationDefinition(def, 0);
    }

    static String traceDefinition(TraceDefinition def, int indent) {
        return null;
    }

    static String traceDefinition(TraceDefinition def) {
        return traceDefinition(def, 0);
    }

    static void bind(Bind b) {
        context.newLevel(context.startRow(), context.endCol());
        pattern(b.getPattern());
        context.merge();
        if (b instanceof SetBind) {
            context.add(sp());
            binaryOperator(BinaryOperator.IN_SET);
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            expression(((SetBind) b).getSet());
            context.merge();
        } else if (b instanceof SeqBind) {
            context.add(sp());
            binaryOperator(BinaryOperator.IN_SEQ);
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            expression(((SeqBind) b).getSeq());
            context.merge();
        } else if (b instanceof TypeBind) {
            context.add(sp());
            String label = ":";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(((TypeBind) b).getType());
            context.merge();
        }
    }

    static void pattern(Pattern p, boolean anchor) {
        if (p instanceof IdentifierPattern) {
            String ip = ((IdentifierPattern) p).getName();
            if (anchor) {
                context.add(HTML.anchor(ip, ip), ip.length());
            } else {
                context.add(ip);
            }
        } else if (p instanceof AnonymousPattern) {
            String label = "-";
            context.add(token(label), label.length());
        } else if (p instanceof ExpressionPattern) {
            context.newLevel(context.startRow(), context.endCol());
            expression(((ExpressionPattern) p).getExpression());
            context.merge();
        } else if (p instanceof BinaryPattern) {
            BinaryPattern be = (BinaryPattern) p;
            context.newLevel(context.startRow(), context.endCol());
            pattern(be.getOp1());
            context.merge();
            context.add(sp());
            binaryOperator(be.getOperator());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            pattern(be.getOp2());
            context.merge();
        } else if (p instanceof SetEnumerationPattern) {
            SetEnumerationPattern sp = (SetEnumerationPattern) p;
            context.ldelim(true, "{");
            context.newLevel(context.startRow(), context.endCol());
            patternList(sp.getItem(), ",", anchor);
            context.merge();
            context.rdelim(true, "}");
        } else if (p instanceof SeqEnumerationPattern) {
            SeqEnumerationPattern sp = (SeqEnumerationPattern) p;
            context.ldelim(true, "[");
            context.newLevel(context.startRow(), context.endCol());
            patternList(sp.getItem(), ",", anchor);
            context.merge();
            context.rdelim(true, "]");
        } else if (p instanceof MapEnumerationPattern) {
            MapEnumerationPattern mp = (MapEnumerationPattern) p;
            context.ldelim(true, "{");
            if (mp.getItem().isEmpty()) {
                String label = "|->";
                context.add(token(label), label.length());
            } else {
                List<Pattern> lp = new ArrayList();
                lp.addAll(mp.getItem());
                context.newLevel(context.startRow(), context.endCol());
                patternList(lp, ",", anchor);
                context.merge();
            }
            context.rdelim(true, "}");
        } else if (p instanceof MapletPattern) {
            MapletPattern mp = (MapletPattern) p;
            context.newLevel(context.startRow(), context.endCol());
            pattern(mp.getDomain(), anchor);
            context.merge();
            binaryOperator(BinaryOperator.MAP);
            context.newLevel(context.startRow(), context.endCol());
            pattern(mp.getRange(), anchor);
            context.merge();
        } else if (p instanceof TuplePattern) {
            TuplePattern tp = (TuplePattern) p;
            String label = "mk_";
            context.add(token(label), label.length());
            context.ldelim(true, "(");
            context.newLevel(context.startRow(), context.endCol());
            patternList(tp.getItem(), ",", anchor);
            context.merge();
            context.rdelim(true, ")");
        } else if (p instanceof RecordPattern) {
            RecordPattern rp = (RecordPattern) p;
            String label = "mk_";
            context.add(token(label), label.length());
            context.newLevel(context.startRow(), context.endCol());
            type(rp.getType());
            context.merge();
            context.ldelim(true, "(");
            context.newLevel(context.startRow(), context.endCol());
            patternList(rp.getItem(), ",", anchor);
            context.merge();
            context.rdelim(true, ")");
        }
    }

    static void pattern(Pattern p) {
        pattern(p, false);
    }

    static void patternList(List<Pattern> lp, String sep, boolean anchor) {
        if (!lp.isEmpty()) {
            //boolean isInline = true;
            //for (Type t : lt) {
            //    isInline = isInline && isInline(t);
            //}
            pattern(lp.get(0), anchor);
            for (Pattern t : lp.subList(1, lp.size())) {
                context.add(sp());
                context.add(token(sep), sep.length());
                context.add(sp());
                if (context.endCol() >= HTMLParameters.maxWidth) {
                    context.nl();
                }
                context.newLevel(context.startRow(), context.endCol());
                pattern(t, anchor);
                context.merge();
            }
        }
    }

    static void patternList(List<Pattern> lp, String sep) {
        patternList(lp, sep, false);
    }

    static void type(Type t, int precedence, String defName) {
        if (t instanceof BasicType) {
            String s = ((BasicType) t).getName().value().replaceAll("_", "");
            context.add(token(s), s.length());
        } else if (t instanceof QuoteType) {
            String s = ((QuoteType) t).getName();
            context.add(HTML.quote(s), s.length() + 2);
        } else if (t instanceof CompositeType) {
            CompositeType c = (CompositeType) t;
            boolean b = precedence(c) < precedence;
            context.ldelim(b, "(");
            if (defName != null && c.getName().equals(defName)) {
                context.newLevel(context.startRow(), context.endCol());
                fieldList(c.getField());
                context.merge();
            } else {
                String label = "compose";
                context.add(token(label), label.length());
                context.add(sp());
                context.add(c.getName());
                context.add(sp());
                label = "of";
                context.add(token(label), label.length());
                if (c.getField().size() < 2) {
                    context.add(sp());
                    context.newLevel(context.startRow(), context.endCol());
                    fieldList(c.getField());
                    context.merge();
                    context.add(sp());
                } else {
                    context.newLevel(context.startRow(), context.startCol() + HTMLParameters.step);
                    context.nl();
                    fieldList(c.getField());
                    context.merge();
                    context.nl();
                }
                label = "end";
                context.add(token(label), label.length());
            }
            context.ldelim(b, ")");
        } else if (t instanceof UnionType) {
            UnionType u = (UnionType) t;
            boolean b = precedence(u) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            typeList(u.getOperand(), precedence(u), "|");
            context.merge();
            context.rdelim(b, ")");
        } else if (t instanceof ProductType) {
            ProductType p = (ProductType) t;
            boolean b = precedence(p) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            typeList(p.getOperand(), precedence(p), "*");
            context.merge();
            context.rdelim(b, ")");
        } else if (t instanceof OptionalType) {
            OptionalType o = (OptionalType) t;
            context.ldelim(true, "[");
            context.newLevel(context.startRow(), context.endCol());
            type(o.getOperand(), precedence(o));
            context.merge();
            context.ldelim(true, "]");
        } else if (t instanceof SetType) {
            SetType s = (SetType) t;
            boolean b = precedence(s) < precedence;
            String label = (s.isNonEmpty() != null && s.isNonEmpty() ? "set1 of" : "set of");
            context.ldelim(b, "(");
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(s.getItem(), precedence(s));
            context.merge();
            context.ldelim(b, ")");
        } else if (t instanceof SeqType) {
            SeqType s = (SeqType) t;
            boolean b = precedence(s) < precedence;
            String label = (s.isNonEmpty() != null && s.isNonEmpty() ? "seq1 of" : "seq of");
            context.ldelim(b, "(");
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(s.getItem(), precedence(s));
            context.merge();
            context.ldelim(b, ")");
        } else if (t instanceof MapType) {
            MapType m = (MapType) t;
            boolean b = precedence(m) < precedence;
            String label = (m.isInjective() != null && m.isInjective() ? "inmap" : "map");
            context.ldelim(b, "(");
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(m.getDomain(), precedence(m));
            boolean brk = (context.startRow() == context.endRow() && context.endCol() >= HTMLParameters.maxWidth
                    || context.startRow() < context.endRow());
            context.merge();
            if (brk) {
                context.nl();
            }
            label = "to";
            context.add(sp());
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(m.getRange(), precedence(m));
            context.merge();
            context.rdelim(b, ")");
        } else if (t instanceof FunctionType) {
            FunctionType f = (FunctionType) t;
            boolean b = precedence(f) < precedence;
            String label = f.isPartial() != null && f.isPartial() ? "->" : "+>";
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            type(f.getDomain(), precedence(f));
            context.merge();
            context.add(sp());
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(f.getRange(), precedence(f));
            context.merge();
            context.rdelim(b, ")");
        } else if (t instanceof NamedType) {
            NamedType n = (NamedType) t;
            String s = HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TYPE);
            s += HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TOOLTIP);
            s += a(n.getModule(), n.getName());
            if (n.getModule() != null) {
                s += HTML.element(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TOOLTIPTEXT, n.getModule());
            }
            s += HTML.closeTag(HTML.SPAN_TAG);
            s += HTML.closeTag(HTML.SPAN_TAG);
            context.add(s, n.getName().length());
        } else if (t instanceof VariableType) {
            String s = '@' + ((VariableType) t).getName();
            context.add(s);
        } else if (t instanceof VoidType) {
            String s = "()";
            context.add(s);
        } else if (t instanceof OperationType) {
            OperationType f = (OperationType) t;
            boolean b = precedence(f) < precedence;
            String label = "==>";
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            type(f.getDomain(), precedence(f));
            context.merge();
            context.add(sp());
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(f.getRange(), precedence(f));
            context.merge();
            context.rdelim(b, ")");
        }
    }

    static void type(Type t, int precedence) {
        type(t, precedence, null);
    }

    static void type(Type t) {
        type(t, 0);
    }

    static String a(String module, String name) {
        return HTML.a(HTML.CLASS_REFERENCE, (module == null ? "" : module + ".html") + "#" + name, HTML.SPEC_FRAME, name);
    }

    private static boolean isInline(Type t) {
        return XSDSupport.isAtomic(t)
                || (t instanceof OptionalType && XSDSupport.isAtomic(((OptionalType) t).getOperand()))
                || (t instanceof SetType && XSDSupport.isAtomic(((SetType) t).getItem()))
                || (t instanceof SeqType && XSDSupport.isAtomic(((SeqType) t).getItem()));
    }

    static void typeList(List<Type> lt, int precedence, String sep) {
        if (!lt.isEmpty()) {
            //boolean isInline = true;
            //for (Type t : lt) {
            //    isInline = isInline && isInline(t);
            //}
            type(lt.get(0), precedence);
            for (Type t : lt.subList(1, lt.size())) {
                context.add(sp());
                context.add(token(sep), sep.length());
                context.add(sp());
                if (context.endCol() >= HTMLParameters.maxWidth) {
                    context.nl();
                }
                context.newLevel(context.startRow(), context.endCol());
                type(t, precedence);
                context.merge();
            }
        }
    }

    static void fieldList(List<LabelledField> lf, int prec) {
        int lw = labelWidth(lf);
        if (!lf.isEmpty()) {
            field(lf.get(0), lw);
            for (LabelledField f : lf.subList(1, lf.size())) {
                context.nl();
                field(f, lw);
            }
        }
    }

    static void fieldList(List<LabelledField> lf) {
        fieldList(lf, 0);
    }

    static int labelWidth(List<LabelledField> lf) {
        int res = 0;
        for (LabelledField f : lf) {
            res = Math.max(res, labelWidth(f));
        }
        return res;
    }

    static void field(LabelledField f, int labelWidth) {
        String res;
        if (f.getName() == null) {
            res = String.format("%-" + (labelWidth + 2) + "s", " ");
        } else {
            res = String.format("%-" + labelWidth + "s", f.getName());
            res += token(f.isEqable() ? ": " : ":-");
        }
        context.add(res, labelWidth + 2);
        context.newLevel(context.startRow(), context.endCol());
        type(f.getType());
        context.merge();
    }

    static int labelWidth(LabelledField lf) {
        return lf.getName() == null ? 0 : lf.getName().length();
    }

    static void expressionList(List<Expression> le, String sep) {
        if (!le.isEmpty()) {
            //boolean isInline = true;
            //for (Type t : lt) {
            //    isInline = isInline && isInline(t);
            //}
            int col = context.startCol();
            context.newLevel(context.startRow(), context.endCol());
            expression(le.get(0));
            context.merge();
            for (Expression e : le.subList(1, le.size())) {
                if (sep == null) {
                    context.nlx(col);
                } else {
                    context.add(sp());
                    context.add(token(sep), sep.length());
                    context.add(sp());
                    if (context.endCol() >= HTMLParameters.maxWidth) {
                        context.nlx(col);
                    }
                }
                context.newLevel(context.startRow(), context.endCol());
                expression(e);
                if (context.multiLine()) {
                    System.out.println("!!!!");
                    context.pop();
                    context.nlx(col);
                    context.newLevel(context.startRow(), context.endCol());
                    expression(e);
                }
                context.merge();
            }
        }
    }

    static void expressionList(List<Expression> le) {
        expressionList(le, null);
    }

    static void expression(Expression e, int precedence) {
        if (e instanceof LetExpression) {
            System.out.println(context.text());
            LetExpression le = (LetExpression) e;
            String label = e instanceof DefExpression ? "def" : "let";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.startCol() + label.length() + 1);
            definitionListLocal(le.getDefinition());
            context.merge();
            context.nl();
            label = "in";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.startCol() + label.length() + 1);
            expression(le.getBody());
            context.merge();
        } else if (e instanceof LetBeExpression) {
            LetBeExpression le = (LetBeExpression) e;
            String label = "let";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.startCol() + label.length() + 1);
            bindList(le.getBind(), ",");
            context.merge();
            if (le.getCondition() != null) {
                context.add(sp());
                label = "be st";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.startCol() + label.length() + 2);
                expression(le.getCondition());
                context.merge();
            }
            context.add(sp());
            label = "in";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.startCol() + label.length() + 1);
            expression(le.getBody());
            context.merge();
        } else if (e instanceof IfExpression) {
            IfExpression ie = (IfExpression) e;
            if (HTMLParameters.altDisplay) {
                /*res += token("if");
                res += sp();
                expression(ie.getIfThen().get(0));
                for (IfThen it : ie.getIfThen().subList(1, ie.getIfThen().size())) {
                    res += "|| ";
                    expression(it);
                    res += nl();
                }
                res += token("fi");*/
            } else {
                String label = "else";
                if (ie.getIfThen().size() == 1) {
                    context.newLevel(context.startRow(), context.endCol());
                    expression(ie.getIfThen().get(0));
                    context.merge();
                    context.add(sp());
                    context.add(token(label), label.length());
                    context.add(sp());
                    context.newLevel(context.startRow(), context.endCol());
                    expression(ie.getElse());
                    context.merge();
                } else {
                    List<Expression> le = new ArrayList();
                    le.addAll(ie.getIfThen());
                    expressionList(le, null);
                    context.add(token(label), label.length());
                    context.add(sp());
                    context.newLevel(context.startRow(), context.endCol());
                    expression(ie.getElse());
                    context.merge();
                }
            }
        } else if (e instanceof IfThen) {
            IfThen ie = (IfThen) e;
            if (HTMLParameters.altDisplay) {
                /*expression(ie.getIf());
                res += sp();
                res += token("->");
                res += sp();
                expression(ie.getThen());*/
            } else {
                String label = "if";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                expression(ie.getIf());
                context.merge();
                context.add(sp());
                label = "then";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                expression(ie.getThen());
                context.merge();
            }
        } else if (e instanceof CasesExpression) {
            CasesExpression ce = (CasesExpression) e;
            String label = "cases";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            expression(ce.getMatch());
            context.merge();
            label = ":";
            context.add(token(label), label.length());
            context.nl(HTMLParameters.step);
            List<Expression> le = new ArrayList();
            le.addAll(ce.getCase());
            context.newLevel(context.startRow(), context.endCol());
            expressionList(le, null);
            context.merge();
            if (ce.getElse() != null) {
                context.nl(HTMLParameters.step);
                label = "others";
                context.add(token(label), label.length());
                label = "->";
                context.add(token(label), label.length());
                context.newLevel(context.startRow(), context.startCol() + HTMLParameters.step);
                expression(ce.getElse());
                context.merge();
            }
            context.nl();
            label = "end";
            context.add(token(label), label.length());
        } else if (e instanceof CaseAlternate) {
            CaseAlternate ce = (CaseAlternate) e;
            context.newLevel(context.startRow(), context.startCol() + HTMLParameters.step);
            pattern(ce.getPattern());
            context.merge();
            context.add(sp());
            String label = "->";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.startCol() + HTMLParameters.step);
            expression(ce.getResult());
            context.merge();
        } else if (e instanceof UnaryExpression) {
            UnaryExpression ue = (UnaryExpression) e;
            boolean b = precedence(ue) < precedence;
            context.ldelim(b, "(");
            unaryOperator(ue.getOperator());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            expression(ue.getOperand(), precedence(ue));
            context.merge();
            context.rdelim(b, ")");
        } else if (e instanceof BinaryExpression) {
            BinaryExpression be = (BinaryExpression) e;
            boolean b = precedence(be) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.startCol() + HTMLParameters.step);
            expression(be.getOp1(), precedence(be));
            context.merge();
            context.add(sp());
            binaryOperator(be.getOperator());
            context.add(sp());
            context.newLevel(context.startRow(), context.startCol() + HTMLParameters.step);
            expression(be.getOp2(), precedence(be));
            context.merge();
            context.rdelim(b, ")");
        } else if (e instanceof QuantifiedExpression) {
            QuantifiedExpression qe = (QuantifiedExpression) e;
            String label = qe.getOperator().value();
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            bindList(qe.getBind(), ",");
            context.merge();
            if (qe.getCondition() != null) {
                label = "&";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                expression(qe.getCondition());
                context.merge();
            }
        } else if (e instanceof SetEnumeration) {
            SetEnumeration se = (SetEnumeration) e;
            context.ldelim(true, "{");
            context.newLevel(context.startRow(), context.endCol());
            expressionList(se.getItem(), ",");
            context.merge();
            context.rdelim(true, "}");
        } else if (e instanceof SetComprehension) {
            SetComprehension sc = (SetComprehension) e;
            context.ldelim(true, "{");
            context.newLevel(context.startRow(), context.endCol());
            expression(sc.getItem());
            context.merge();
            context.add(sp());
            String label = "|";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            bindList(sc.getBind(), ",");
            context.merge();
            if (sc.getCondition() != null) {
                context.add(sp());
                label = "&";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                expression(sc.getCondition());
                context.merge();
            }
            context.rdelim(true, "}");
        } else if (e instanceof SetRange) {
            range(((SetRange) e).getRange(), "{", ",...,", "}");
        } else if (e instanceof SeqEnumeration) {
            SeqEnumeration se = (SeqEnumeration) e;
            context.ldelim(true, "[");
            context.newLevel(context.startRow(), context.endCol());
            expressionList(se.getItem(), ",");
            context.merge();
            context.rdelim(true, "]");
        } else if (e instanceof SeqComprehension) {
            SeqComprehension sc = (SeqComprehension) e;
            context.ldelim(true, "[");
            context.newLevel(context.startRow(), context.endCol());
            expression(sc.getItem());
            context.merge();
            context.add(sp());
            String label = "|";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            bindList(sc.getBind(), ",");
            context.merge();
            if (sc.getCondition() != null) {
                context.add(sp());
                label = "&";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                expression(sc.getCondition());
                context.merge();
            }
            context.rdelim(true, "]");
        } else if (e instanceof Subsequence) {
            Subsequence ts = (Subsequence) e;
            boolean b = precedence(ts) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            expression(ts.getSeq(), precedence(ts));
            context.merge();
            range(ts.getRange(), "(", ",...,", ")");
            context.rdelim(b, ")");
        } else if (e instanceof MapEnumeration) {
            MapEnumeration me = (MapEnumeration) e;
            context.ldelim(true, "{");
            if (me.getItem().isEmpty()) {
                String label = "|->";
                context.add(token(label), label.length());
            } else {
                List<Expression> le = new ArrayList();
                le.addAll(me.getItem());
                context.newLevel(context.startRow(), context.endCol());
                expressionList(le, ",");
                context.merge();
            }
            context.rdelim(true, "}");
        } else if (e instanceof MapComprehension) {
            MapComprehension sc = (MapComprehension) e;
            context.ldelim(true, "{");
            context.newLevel(context.startRow(), context.endCol());
            expression(sc.getItem());
            context.merge();
            context.add(sp());
            String label = "|";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            bindList(sc.getBind(), ",");
            context.merge();
            if (sc.getCondition() != null) {
                context.add(sp());
                label = "&";
                context.add(token(label), label.length());
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                expression(sc.getCondition());
                context.merge();
            }
            context.rdelim(true, "}");
        } else if (e instanceof Maplet) {
            Maplet be = (Maplet) e;
            context.newLevel(context.startRow(), context.endCol());
            expression(be.getDomain());
            context.merge();
            binaryOperator(BinaryOperator.MAP);
            context.newLevel(context.startRow(), context.endCol());
            expression(be.getRange());
            context.merge();
        } else if (e instanceof TupleExpression) {
            TupleExpression te = (TupleExpression) e;
            String label = "mk_";
            context.add(token(label), label.length());
            context.ldelim(true, "(");
            List<Expression> le = new ArrayList();
            le.addAll(te.getItem());
            context.newLevel(context.startRow(), context.endCol());
            expressionList(le, ",");
            context.merge();
            context.rdelim(true, ")");
        } else if (e instanceof RecordExpression) {
            RecordExpression re = (RecordExpression) e;
            String label = "mk_";
            context.add(token(label), label.length());
            context.newLevel(context.startRow(), context.endCol());
            type(re.getType());
            context.merge();
            context.ldelim(true, "(");
            List<Expression> le = new ArrayList();
            le.addAll(re.getItem());
            context.newLevel(context.startRow(), context.endCol());
            expressionList(le, ",");
            context.merge();
            context.rdelim(true, ")");
        } else if (e instanceof RecordModification) {
            RecordModification rm = (RecordModification) e;
            boolean b = precedence(rm) < precedence;
            context.ldelim(b, "(");
            String label = "mu";
            context.add(token(label), label.length());
            context.ldelim(true, "(");
            List<Expression> le = new ArrayList();
            le.add(rm.getRecord());
            le.addAll(rm.getModifier());
            context.newLevel(context.startRow(), context.endCol());
            expressionList(le, ",");
            context.merge();
            context.rdelim(true, ")");
            context.rdelim(b, ")");
        } else if (e instanceof RecordModifier) {
            RecordModifier rm = (RecordModifier) e;
            context.add(rm.getName());
            String label = Operator.display(BinaryOperator.MAP);
            context.add(token(label), label.length());
            context.newLevel(context.startRow(), context.endCol());
            expression(rm.getValue());
            context.merge();
        } else if (e instanceof ApplyExpression) {
            ApplyExpression ts = (ApplyExpression) e;
            boolean b = precedence(ts) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            expression(ts.getFunction());
            context.merge();
            /* Don't present the type arguments.
            if (!ts.getType().isEmpty()) {
                res += typeList(ts.getType(),indent+res.length(), "[", ",", "]");
            } */
            context.ldelim(true, "(");
            context.newLevel(context.startRow(), context.endCol());
            expressionList(ts.getArgument(), ",");
            context.merge();
            context.rdelim(true, ")");
            context.rdelim(b, ")");
        } else if (e instanceof RecordSelectExpression) {
            RecordSelectExpression ts = (RecordSelectExpression) e;
            boolean b = precedence(ts) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            expression(ts.getRecord());
            context.merge();
            String label = ".";
            context.add(token(label), label.length());
            context.add(ts.getField());
            context.rdelim(b, ")");
        } else if (e instanceof TupleSelectExpression) {
            TupleSelectExpression ts = (TupleSelectExpression) e;
            boolean b = precedence(ts) < precedence;
            context.ldelim(b, "(");
            context.newLevel(context.startRow(), context.endCol());
            expression(ts.getTuple());
            context.merge();
            String label = ".#";
            context.add(token(label), label.length());
            context.add(String.format("%d", ts.getField()));
            context.rdelim(b, ")");
        } else if (e instanceof LambdaExpression) {
            LambdaExpression qe = (LambdaExpression) e;
            boolean b = precedence(qe) < precedence;
            context.ldelim(b, "(");
            String label = "lambda";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            bindList(qe.getBind(), ",");
            context.merge();
            context.add(sp());
            label = "&";
            context.add(token(label), label.length());
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            expression(qe.getBody());
            context.merge();
            context.rdelim(b, ")");
        } else if (e instanceof NarrowExpression) {
            NarrowExpression ne = (NarrowExpression) e;
            boolean b = precedence(ne) < precedence;
            context.ldelim(b, "(");
            String label = "narrow";
            context.add(token(label), label.length());
            context.ldelim(true, "(");
            context.newLevel(context.startRow(), context.endCol());
            expression(ne.getExpression());
            context.merge();
            context.add(sp());
            context.add(",");
            context.add(sp());
            context.newLevel(context.startRow(), context.endCol());
            type(ne.getType());
            context.merge();
            context.rdelim(true, ")");
            context.rdelim(b, ")");
        } else if (e instanceof IsExpression) {
            IsExpression ie = (IsExpression) e;
            boolean b = precedence(ie) < precedence;
            context.ldelim(b, "(");
            boolean isSimple = XSDSupport.isAtomic(ie.getType());
            String label = "is_";
            context.add(token(label), label.length());
            if (isSimple) {
                type(ie.getType());
            }
            context.ldelim(true, "(");
            context.newLevel(context.startRow(), context.endCol());
            expression(ie.getExpression());
            context.merge();
            if (!isSimple) {
                context.add(sp());
                context.add(",");
                context.add(sp());
                context.newLevel(context.startRow(), context.endCol());
                type(ie.getType());
                context.merge();
            }
            context.rdelim(true, ")");
            context.rdelim(b, ")");
        } else if (e instanceof UndefinedExpression) {
            String label = "undefined";
            context.add(token(label), label.length());
        } else if (e instanceof PreExpression) {
            PreExpression re = (PreExpression) e;
            boolean b = precedence(re) < precedence;
            context.ldelim(b, "(");
            String label = "mk_";
            context.add(token(label), label.length());
            context.ldelim(true, "(");
            List<Expression> le = new ArrayList();
            le.add(re.getFunction());
            le.addAll(re.getArgument());
            context.newLevel(context.startRow(), context.endCol());
            expressionList(le, ",");
            context.merge();
            context.rdelim(true, ")");
            context.rdelim(b, ")");
        } else if (e instanceof NameExpression) {
            NameExpression n = (NameExpression) e;
            String kind = null;
            if (n instanceof ValueIdentifier) {
                kind = HTML.CLASS_VALUE;
            } else if (n instanceof FunctionIdentifier) {
                kind = HTML.CLASS_FUNCTION;
            } else if (n instanceof OperationIdentifier) {
                kind = HTML.CLASS_OPERATION;
            }
            String s;
            if (kind == null) {
                s = n.getName();
            } else {
                s = HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, kind);
                if (n.getModule() != null) {
                    s += HTML.openTag(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TOOLTIP);
                }
                if (true) {
                    s += a(n.getModule(), n.getName());
                } else {
                    s += n.getName();
                }
                if (n.getModule() != null) {
                    s += HTML.element(HTML.SPAN_TAG, HTML.ATTRIBUTE_CLASS, HTML.CLASS_TOOLTIPTEXT, n.getModule());
                    s += HTML.closeTag(HTML.SPAN_TAG);
                }
                s += HTML.closeTag(HTML.SPAN_TAG);
            }
            context.add(s, n.getName().length());
        } else if (e instanceof BooleanLiteralExpression) {
            String label = ((BooleanLiteralExpression) e).isValue() ? "true" : "false";
            context.add(token(label), label.length());
        } else if (e instanceof CharacterLiteralExpression) {
            String label = "'" + ((CharacterLiteralExpression) e).getValue() + "'";
            context.add(token(label), label.length());
        } else if (e instanceof TextLiteralExpression) {
            String label = "\"" + ((TextLiteralExpression) e).getValue() + "\"";
            context.add(token(label), label.length());
        } else if (e instanceof IntegralLiteralExpression) {
            String label = String.format("%d", ((IntegralLiteralExpression) e).getValue());
            context.add(token(label), label.length());
        } else if (e instanceof DecimalLiteralExpression) {
            String label = String.format("%s", ((DecimalLiteralExpression) e).getValue());
            context.add(token(label), label.length());
        } else if (e instanceof QuoteLiteralExpression) {
            String label = ((QuoteLiteralExpression) e).getValue();
            context.add(HTML.quote(label), label.length() + 2);
        } else if (e instanceof NilLiteralExpression) {
            String label = "nil";
            context.add(token(label), label.length());
        } else if (e instanceof ResultExpression) {
            String label = "RESULT";
            context.add(token(label), label.length());
        }
    }

    static void expression(Expression e) {
        expression(e, 0);
    }

    private static int precedence(Expression e) {
        if (e instanceof UnaryExpression) {
            return Operator.precedence(((UnaryExpression) e).getOperator());
        }
        if (e instanceof BinaryExpression) {
            return Operator.precedence(((BinaryExpression) e).getOperator());
        }
        return Operator.MAX_PRECEDENCE;
    }

    private static int precedence(Type t) {
        if (t instanceof OptionalType) {
            return 99;
        }
        if (t instanceof OperationType || t instanceof FunctionType) {
            return 100;
        }
        if (t instanceof CompositeType) {
            return 101;
        }
        if (t instanceof UnionType) {
            return 102;
        }
        if (t instanceof ProductType) {
            return 103;
        }
        if (t instanceof MapType) {
            return 104;
        }
        if (t instanceof SetType || t instanceof SeqType) {
            return 105;
        }
        return Operator.MAX_PRECEDENCE;
    }

    private static void unaryOperator(UnaryOperator op) {
        context.add(token(Operator.display(op)), Operator.width(op));
    }

    private static void binaryOperator(BinaryOperator op) {
        context.add(token(Operator.display(op)), Operator.width(op));
    }

    private static String token(String token) {
        if (token == null) {
            return "";
        }
        if (Keyword.is(token)) {
            return HTML.keyword(token);
        } else {
            return token;
        }
    }

    private static String pad(UnaryOperator op) {
        return Operator.isPad(op) ? sp() : "";
    }

    private static String pad(BinaryOperator op) {
        return Operator.isPad(op) ? sp() : "";
    }

    private static String pad(int indent) {
        return indent == 0 ? "" : String.format("%" + indent + "c", ' ');
    }

    private static String sp() {
        return pad(1);
    }

    private static String nl() {
        return "\n";
    }

    private static String nl(int indent) {
        return "\n" + pad(indent);
    }

    static void range(Range range, String pre, String sep, String post) {
        context.add(token(pre), pre.length());
        context.newLevel(context.startRow(), context.endCol());
        expression(range.getLower());
        context.merge();
        context.add(token(sep), sep.length());
        context.newLevel(context.startRow(), context.endCol());
        expression(range.getUpper());
        context.merge();
        context.add(token(post), post.length());
    }

    static String statement(Statement s) {
        return null;
    }
}
