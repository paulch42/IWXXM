
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HTML {

    // General definitions.
    public static final String INDEX_FILE = "index.html";
    public static final String MENU_FILE = "menu.html";
    public static final String SPEC_FRAME = "Specification";
    public static final String DOCTYPE = "<!DOCTYPE html>";
    public static final String CHARSET = "<meta charset=\"UTF-8\">";

    // The names of HTML tags.
    public static final String HTML_TAG = "html";
    public static final String HEAD_TAG = "head";
    public static final String TITLE_TAG = "title";
    public static final String BODY_TAG = "body";
    public static final String HEADER_TAG = "header";
    public static final String DETAILS_TAG = "details";
    public static final String SUMMARY_TAG = "summary";
    public static final String SPAN_TAG = "span";
    public static final String DIV_TAG = "div";
    public static final String SECTION_TAG = "section";
    public static final String FIELDSET_TAG = "fieldset";
    public static final String LEGEND_TAG = "legend";
    public static final String A_TAG = "a";
    public static final String P_TAG = "p";
    public static final String H1_TAG = "h1";
    public static final String H2_TAG = "h2";
    public static final String H3_TAG = "h3";
    public static final String HR_TAG = "hr";
    public static final String UL_TAG = "ul";
    public static final String LI_TAG = "li";
    public static final String IFRAME_TAG = "iframe";
    public static final String CODE_TAG = "code";

    // The names of HTML attributes.
    public static final String ATTRIBUTE_CLASS = "class";
    public static final String ATTRIBUTE_NAME = "name";
    public static final String ATTRIBUTE_HREF = "href";
    public static final String ATTRIBUTE_TARGET = "target";
    public static final String ATTRIBUTE_ID = "id";
    public static final String ATTRIBUTE_SRC = "src";

    // The names of defined CSS classes.
    public static final String CLASS_LIST = "list";
    public static final String CLASS_SPEC = "spec";
    public static final String CLASS_MENU = "menu";
    public static final String CLASS_EXPOSE = "expose";
    public static final String CLASS_EXPORT = "export";
    public static final String CLASS_NOEXPORT = "noexport";
    public static final String CLASS_DEFINITION = "definition";
    public static final String CLASS_KEYWORD = "keyword";
    public static final String CLASS_TYPE = "type";
    public static final String CLASS_STATE = "state";
    public static final String CLASS_COMMENT = "comment";
    public static final String CLASS_VALUE = "value";
    public static final String CLASS_FUNCTION = "function";
    public static final String CLASS_OPERATION = "operation";
    public static final String CLASS_REFERENCE = "reference";
    public static final String CLASS_MODULE = "module";
    public static final String CLASS_QUOTE = "quote";
    public static final String CLASS_TOOLTIP = "tooltip";
    public static final String CLASS_TOOLTIPTEXT = "tooltiptext";

    // The names of element identifiers.
    public static final String ID_IMPORTS = "imports";
    public static final String ID_EXPORTS = "exports";
    public static final String ID_TYPES = "types";
    public static final String ID_STATE = "state";
    public static final String ID_VALUES = "values";
    public static final String ID_FUNCTIONS = "functions";
    public static final String ID_OPERATIONS = "operations";

    public static final String doctype() {
        return DOCTYPE;
    }

    public static String head(String moduleName, String vdmCssFilename, String customCssFilename) {
        String res = openTag(HEAD_TAG);
        res += title(moduleName);
        res += CHARSET;
        res += link(vdmCssFilename);
        if (customCssFilename != null) {
            res += link(customCssFilename);
        }
        return res + closeTag(HEAD_TAG);
    }

    public static String head(String moduleName, String vdmCssFilename) {
        return head(moduleName, vdmCssFilename, null);
    }

    public static String title(String title) {
        return element(TITLE_TAG, title);
    }

    public static String link(String filename) {
        return String.format("<link href=\"%s\" rel=\"stylesheet\">", filename);
    }

    /*
      Methods that create HTML elements, with attributes and content.
     */
    public static String element(String tag, String key, String value, String content) {
        return openTag(tag, key, value) + content + closeTag(tag);
    }

    public static String element(String tag, String key, String value) {
        return element(tag, key, value, "");
    }

    public static String element(String tag, String content) {
        return openTag(tag) + content + closeTag(tag);
    }

    public static String element(String tag) {
        return String.format("<%s/>", tag);
    }

    /*
      Methods that create HTML open and close tags.
     */
    public static String openTag(String tag, Map<String, String> attr) {
        String res = '<' + tag;
        if (attr != null && attr.size() > 0) {
            for (String s : attr.keySet()) {
                String val = attr.get(s);
                if (val == null) {
                    res += String.format(" %s", s);
                } else {
                    res += String.format(" %s=\"%s\"", s, val);
                }
            }
        }
        return res + '>';
    }

    public static String openTag(String tag, String key, String value) {
        Map<String, String> attrs = new HashMap();
        attrs.put(key, value);
        return openTag(tag, attrs);
    }

    public static String openTag(String tag) {
        return openTag(tag, null);
    }

    public static String closeTag(String tag) {
        return String.format("</%s>", tag);
    }

    /* HTML formatted VDM keyword. */
    public static String keyword(String qt) {
        return element(SPAN_TAG, ATTRIBUTE_CLASS, CLASS_KEYWORD, qt);
    }

    /* HTML formatted VDM quote.*/
    public static String quote(String qt) {
        return element(SPAN_TAG, ATTRIBUTE_CLASS, CLASS_QUOTE, "&lt;" + qt + ">");
    }

    public static String anchor(String id, String label) {
        return String.format("<a %s=\"%s\">%s</a>", ATTRIBUTE_ID, id, label);
    }

    public static String a(String classId, String href, String target, String label) {
        String res = "<a";
        if (classId != null) {
            res += String.format(" %s=\"%s\"", ATTRIBUTE_CLASS, classId);
        }
        res += String.format(" %s=\"%s\"", ATTRIBUTE_HREF, href);
        if (target != null) {
            res += String.format(" %s=\"%s\"", ATTRIBUTE_TARGET, target);
        }
        res += ">" + label;
        return res + closeTag(A_TAG);
    }

    public static String a(String classId, String href, String label) {
        return a(classId, href, null, label);
    }

    public static String a(String href, String label) {
        return a((String) null, href, label);
    }

    public static String openDetails(boolean open, String tag, String value) {
        return String.format("<%s %s %s=\"%s\">", DETAILS_TAG, open ? "open" : "", tag, value);
    }

    public static String openDetails(boolean open) {
        return String.format("<%s %s>", DETAILS_TAG, open ? "open" : "");
    }

    /*
      General formatting utilities.
     */
    public static String newline(int n) {
        return newline() + pad(n);
    }

    public static String newline() {
        return "\n";
    }

    public static String pad(int indent) {
        return indent == 0 ? "" : String.format("%" + indent + "c", ' ');
    }

    public static List<String> getHTMLComments(List<String> comments) {
        List<String> result = new ArrayList();
        for (String s : comments) {
            s = s.trim();
            if (s.startsWith("<")) {
                result.add(s);
            }
        }
        return result;
    }
}
