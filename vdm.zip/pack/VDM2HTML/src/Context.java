
import java.util.Stack;

public class Context extends Stack<ContextLevel> {

    public boolean multiLine() {
        ContextLevel cl = peek();
        if (cl != null) {
            return cl.multiLine();
        }
        return false;
    }

    public void newLevel(int startRow, int startCol) {
        super.add(new ContextLevel(startRow, startCol));
    }

    public void setEnd(int endRow, int endCol) {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.setEnd(endRow, endCol);
        }
    }

    public void add(String text, int length) {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.add(text, length);
        }
    }

    public void add(String text) {
        add(text, text.length());
    }

    public void nl(int step) {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.nl(step);
        }
    }

    public void nlx(int step) {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.nlx(step);
        }
    }

    public void ldelim(boolean b, String delim) {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.ldelim(b, delim);
        }
    }

    public void rdelim(boolean b, String delim) {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.rdelim(b, delim);
        }
    }

    public void nl() {
        ContextLevel cl = peek();
        if (cl != null) {
            cl.nl();
        }
    }

    public int startRow() {
        ContextLevel cl = peek();
        if (cl != null) {
            return cl.startRow;
        }
        return -1;
    }

    public int startCol() {
        ContextLevel cl = peek();
        if (cl != null) {
            return cl.startCol;
        }
        return -1;
    }

    public int endRow() {
        ContextLevel cl = peek();
        if (cl != null) {
            return cl.endRow;
        }
        return -1;
    }

    public int endCol() {
        ContextLevel cl = peek();
        if (cl != null) {
            return cl.endCol;
        }
        return -1;
    }

    public String text() {
        ContextLevel cl = peek();
        if (cl != null) {
            return cl.text;
        }
        return null;
    }

    public void merge() {
        if (size() > 1) {
            ContextLevel cl = pop();
            peek().merge(cl);
        }
    }
}
