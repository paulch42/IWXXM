
import org.overture.vdm.xsd.SpecificationSet;
import org.overture.vdm.xsd.XSDSupport;

public class Main {

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Usage: VDM2HTML <config> <source>");
            System.exit(0);
        }
        String result = HTMLParameters.load(args[0]);
        if (result != null) {
            System.out.println(result);
            System.exit(-1);
        }
        result = Operator.load(HTMLParameters.operatorFile);
        if (result != null) {
            System.out.println(result);
            System.exit(-1);
        }
        SpecificationSet ss = XSDSupport.unmarshal(args[1]);
        VDM2HMTL.VDM2HTML(ss);
    }
}
