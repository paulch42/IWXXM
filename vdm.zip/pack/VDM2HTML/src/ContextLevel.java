
public class ContextLevel {

    int startRow;
    int startCol;
    int endRow;
    int endCol;
    String text;

    ContextLevel(int startRow, int startCol) {
        this.startRow = startRow;
        this.startCol = startCol;
        endRow = startRow;
        endCol = startCol;
        text = "";
    }
    
    boolean multiLine() {
        return endRow > startRow;
    }

    void setEnd(int endRow, int endCol) {
        this.endRow = endRow;
        this.endCol = endCol;
    }

    void add(String text, int length) {
        if (text != null) {
            this.endCol += length;
            this.text += text;
        }
    }

    void add(String text) {
        if (text != null) {
            add(text, text.length());
        }
    }

    void ldelim(boolean b, String delim) {
        if (b && delim != null) {
            add(delim);
            startCol += delim.length();
        }
    }

    void rdelim(boolean b, String delim) {
        if (b && delim != null) {
            add(delim);
            //????
        }
    }

    void nl(int step) {
        nl();
        add(String.format("%" + step + "c", ' '));
    }

    void nl() {
        endRow += 1;
        endCol = startCol;
        text += '\n';
        if (endCol > 0) {
            text += String.format("%" + endCol + "c", ' ');
        }
    }
    
    void nlx(int col) {
        endRow += 1;
        endCol = col;
        text += '\n';
        if (endCol > 0) {
            text += String.format("%" + endCol + "c", ' ');
        }
    }

    void merge(ContextLevel cl) {
        if (cl != null) {
            endRow = cl.endRow;
            endCol = cl.endCol;
            text += cl.text;
        }
    }
}
