import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class HTMLParameters
{
    private static final String CSS_FILENAME = "cssfilename";
    private static final String CUSTOM_FILENAME = "customfilename";
    private static final String OPERATOR_FILENAME = "operatorfilename";
    private static final String MAX_WIDTH = "maxwidth";
    private static final String STEP = "step";
    private static final String ALT_DISPLAY = "altdisplay";
    
    public static String cssFile;
    public static String customFile;
    public static String operatorFile;
    public static int maxWidth;
    public static int step;
    public static boolean altDisplay;
    
    public static String load(String file)
    {
        Properties prop = new Properties();
        InputStream is = null;
        try
        {
            is = new FileInputStream(file);
            prop.load(is);
            is.close();
            cssFile = prop.getProperty(CSS_FILENAME);
            if (cssFile == null)
            {
                return String.format("Property '%s' missing", CSS_FILENAME);
            }
            customFile = prop.getProperty(CUSTOM_FILENAME);
            operatorFile = prop.getProperty(OPERATOR_FILENAME);
            if (operatorFile == null)
            {
                return String.format("Property '%s' missing", OPERATOR_FILENAME);
            }
            String maxWidthS = prop.getProperty(MAX_WIDTH);
            if (maxWidthS == null)
            {
                maxWidth = 80;
            }
            else
            {
                try
                {
                    maxWidth = Integer.parseInt(maxWidthS);
                }
                catch (Exception e)
                {
                    return String.format("Invalid maxWidth parameter: '%s'", maxWidthS);
                }
            }
            String stepS = prop.getProperty(STEP);
            if (stepS == null)
            {
                step = 2;
            }
            else
            {
                try
                {
                    maxWidth = Integer.parseInt(stepS);
                }
                catch (Exception e)
                {
                    return String.format("Invalid step parameter: '%s'", stepS);
                }
            }
            String alt = prop.getProperty(ALT_DISPLAY);
            altDisplay = alt != null && !alt.isEmpty();
        }
        catch (IOException e)
        {
            try{is.close();} catch (Exception f) {}
            return "Failure reading HTML configuration file";
        }
        return null;
    }
}
