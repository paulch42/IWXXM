
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.HashMap;
import java.util.Map;
import org.overture.vdm.xsd.BinaryOperator;
import org.overture.vdm.xsd.UnaryOperator;

/*
  Characteristics and utility methods for handling VDM operators. Both expression
  and type operators.
 */
public class Operator {

    static final int MAX_PRECEDENCE = 1000;

    // Unary expression operators
    private static final Map<UnaryOperator, Characteristic> unaryOperators;
    // Binary expression operators
    private static final Map<BinaryOperator, Characteristic> binaryOperators;
    // Unary type operators
    private static final Map<UnaryOperator, Characteristic> unaryTypeOperators;
    // Binary type operators
    private static final Map<BinaryOperator, Characteristic> binaryTypeOperators;

    static {
        unaryOperators = new HashMap();
        binaryOperators = new HashMap();
        unaryTypeOperators = new HashMap();
        binaryTypeOperators = new HashMap();
    }
//        unaryOperators.put("return",  new Characteristic(Associativity.None, 101));
//        unaryOperators.put("dcl",  new Characteristic(Associativity.None, 101));
//        unaryOperators.put("pre",  new Characteristic(Associativity.None, 101));
//        unaryOperators.put("post",  new Characteristic(Associativity.None, 101));
//        unaryOperators.put("measure",  new Characteristic(Associativity.None, 101));
//        binaryOperators.put(".",  new Characteristic(Associativity.Left, 501, false));
//        binaryOperators.put(".#",  new Characteristic(Associativity.Left, 501, false));
//        binaryOperators.put("",  new Characteristic(Associativity.Left, 501, false));
//        binaryOperators.put(",...,",  new Characteristic(Associativity.None, 501));
//        binaryOperators.put(",",  new Characteristic(Associativity.None, 0));
//        binaryOperators.put("|->", new Characteristic(Associativity.None, 0));
//        binaryOperators.put(":=",  new Characteristic(Associativity.None, 0));
//        binaryOperators.put(":",  new Characteristic(Associativity.None, 0));
//        binaryOperators.put(":-",  new Characteristic(Associativity.None, 0));
//        binaryOperators.put("==",  new Characteristic(Associativity.None, 0));
//        binaryOperators.put("::",  new Characteristic(Associativity.None, 0));

    /*
      The kinds of associativity for operators.
     */
    static enum Associativity {
        Left,
        Right,
        Assoc,
        None
    }

    /*
      The characteristics of an operator.
     */
    private static class Characteristic {

        Associativity assoc; // Operator associativity
        Integer precedence;  // Operator precedence
        String display;      // How the operator is displayed
        int width;           // The number of characters required to display the operator

        Characteristic(Associativity assoc, int precedence, String display, int width) {
            this.assoc = assoc;
            this.precedence = precedence;
            this.display = display;
            this.width = width;
        }

        Characteristic(Associativity assoc, int precedence, String display) {
            this(assoc, precedence, display, display.length());
        }
    }

    // Read operator configuration information from a file.
    public static String load(String file) {
        LineNumberReader in = null;
        try {
            in = new LineNumberReader(new FileReader(file));
            String line;
            do {
                line = in.readLine();
                if (line != null && !line.isEmpty() && line.charAt(0) != '#') {
                    String[] tokens = line.split("\\h+");
                    String name = tokens[0];
                    String assoc = tokens[2];
                    Associativity associativity;
                    switch (assoc) {
                        case "R":
                            associativity = Associativity.Right;
                            break;
                        case "L":
                            associativity = Associativity.Left;
                            break;
                        case "A":
                            associativity = Associativity.Assoc;
                            break;
                        default:
                            associativity = Associativity.None;
                    }
                    int precedence = Integer.parseInt(tokens[3]);
                    String display = name.replace('-', ' ');
                    if (tokens.length > 4) {
                        display = tokens[4];
                    }
                    int width = display.length();
                    if (tokens.length > 5) {
                        width = Integer.parseInt(tokens[5]);
                    }
                    switch (tokens[1]) {
                        case "U":
                            unaryOperators.put(UnaryOperator.fromValue(name), new Characteristic(associativity, precedence, display, width));
                            break;
                        case "B":
                            binaryOperators.put(BinaryOperator.fromValue(name), new Characteristic(associativity, precedence, display, width));
                            break;
                        default:
                            return "Invalid operator type: " + tokens[1];
                    }
                }
            } while (line != null);
            in.close();
        } catch (IOException e) {
            try {
                in.close();
            } catch (Exception f) {
            }
            return "Failure reading Operator configuration file";
        }
        return null;
    }

    // The associativity to a binary expression operator.
/*    static Associativity bassoc(String op) {
        return binaryOperators.get(op).assoc;
    }

    // The precedence to a binary expression operator.
    static Integer bprecedence(String op) {
        return binaryOperators.get(op).precedence;
    }

    // The associativity to a unary expression operator.
    static Associativity uassoc(String op) {
        return unaryOperators.get(op).assoc;
    }

    // The precedence to a unary expression operator.
    static Integer uprecedence(String op) {
        return unaryOperators.get(op).precedence;
    }

    // The associativity to a binary type operator.
    static Associativity bassocType(String op) {
        return binaryTypeOperators.get(op).assoc;
    }

    // The precedence to a binary type operator.
    static Integer bprecedenceType(String op) {
        return binaryTypeOperators.get(op).precedence;
    }

    // The associativity to a unary type operator.
    static Associativity uassocType(String op) {
        return unaryTypeOperators.get(op).assoc;
    }

    // The precedence to a unary type operator.
    static Integer uprecedenceType(String op) {
        return unaryTypeOperators.get(op).precedence;
    }

    // Is the argument a binary operator; expression or type?
    static boolean isBinaryOperator(String op) {
        return binaryOperators.get(op) != null || binaryTypeOperators.get(op) != null;
    }

    // Is the argument a unary operator; expression or type?
    static boolean isUnaryOperator(String op) {
        return unaryOperators.get(op) != null || unaryTypeOperators.get(op) != null;
    }
     */
    static int precedence(UnaryOperator op) {
        Characteristic dc = unaryOperators.get(op);
        if (dc != null) {
            return dc.precedence;
        }
        return MAX_PRECEDENCE;
    }

    static int precedence(BinaryOperator op) {
        Characteristic dc = binaryOperators.get(op);
        if (dc != null) {
            return dc.precedence;
        }
        return MAX_PRECEDENCE;
    }

    static String display(UnaryOperator op) {
        Characteristic dc = unaryOperators.get(op);
        if (dc == null) {
            return op.value();
        }
        return dc.display;
    }

    static String display(BinaryOperator op) {
        Characteristic dc = binaryOperators.get(op);
        if (dc == null) {
            return op.value();
        }
        return dc.display;
    }

    static int width(UnaryOperator op) {
        Characteristic dc = unaryOperators.get(op);
        if (dc == null) {
            return op.value().length();
        }
        return dc.width;
    }

    static int width(BinaryOperator op) {
        Characteristic dc = binaryOperators.get(op);
        if (dc == null) {
            return op.value().length();
        }
        return dc.width;
    }

    // Does the unary operator that require padding?
    public static boolean isPad(UnaryOperator op) {
        String d = display(op);
        return d != null && !d.isEmpty() && Character.isAlphabetic(d.charAt(0));
    }

    // Does the binary operator that require padding?
    public static boolean isPad(BinaryOperator op) {
        String d = display(op);
        return d != null && !d.isEmpty() && Character.isAlphabetic(d.charAt(0));
    }
}
